complie:
	gcc main.c -o test
execute:
	.\test chinhta.txt